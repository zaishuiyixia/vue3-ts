import HyTextLink from './src/textlink.vue'
export default HyTextLink
