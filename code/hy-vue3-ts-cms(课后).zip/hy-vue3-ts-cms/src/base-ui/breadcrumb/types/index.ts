export interface IBreadcrumb {
  name: string
  path?: string
}
